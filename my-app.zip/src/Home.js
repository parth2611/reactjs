import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class Home extends React.Component{
    render()
    {
        return(
            <div>
            <p>  I am Home Page</p>
            </div>
        )
    }
}
export default Home;
