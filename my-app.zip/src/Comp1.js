import React, { Component } from 'react';

class Comp1 extends Component {
  render() {
    return (
     <p>Hi I am Component1</p>
    );
  }
}

class Comp2 extends Component {
    render() {
      return (
       <p>Hi I am Component2</p>
      );
    }
  }

  class MainComponent extends React.Component{
 
    render()
    {
        return(
            <div>
                <Comp1 />
                <Comp2 />
            </div>
        )
    }

}
export default MainComponent;
