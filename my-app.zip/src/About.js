import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class About extends React.Component{
    render()
    {
        return(
            <div style='background-color:red;'>
            <p>I am About us</p>
            </div>
        )
    }

}
export default About;
