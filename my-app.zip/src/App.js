import React, { Component } from 'react';
import { BrowserRouter as Router,Switch, Route, Link } from 'react-router-dom'
import Home from './Home'; 
import About from './About'; 
import './App.css';

class App extends Component {
  render() {
    return (
      <Router>
       <div> 
          <Link to={'/'}>Home</Link>
          <Link to={'/about'}>About</Link>
        <Switch>
       <Route exact path='/' Component={Home} /> 
       <Route exact path='/about' Component={About} /> 
        </Switch>
      </div>
      </Router>
    );
  }
}
export default App;
